# Project Description
WPF MessageBox is an implementation of a fully customizable MessageBox in WPF which has the exact same interface as the standard MessageBox class.
Customizing the message box is done by using styles and control templates.

![](Home_http://download.codeplex.com/download?ProjectName=wpfmessagebox&DownloadId=237780)

# Features
* The class WPFMessageBox has the exact same interface as the current WPF MessageBox class.
* Implemented as a custom control, thus fully customizable via standard WPF control templates.
* Has a default control template which looks like the standard MessageBox.
* Supports all the common types of message boxes: Error, Warning, Question and Information.
* Has the same “Beep” sounds as when opening a standard MessageBox.
* Supports the same behavior when pressing the Escape button as the standard MessageBox.
* Provides the same system menu as the standard MessageBox, including disabling the Close button when the message box is in Yes-No mode.
* Handles right-aligned and right-to-left operating systems, same as the standard MessageBox.
* Provides support for setting the owner window as a WinForms Form control.
