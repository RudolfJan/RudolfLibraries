Latest and most up-to-date information on this project can be found on my blog: [blogs.microsoft.co.il/blogs/arik](blogs.microsoft.co.il/blogs/arik)

## How to use it?
Using the WPFMessageBox class is (exactly) as simple as presenting a standard MessageBox.

Instead of writing:

{code:c#}
MessageBoxResult result = MessageBox.Show("message text", "caption", MessageBoxButton.YesNoCancel, MessageBoxImage.Error);
{code:c#}

simply write:

{code:c#}
MessageBoxResult result = WPFMessageBox.Show("message text", "caption", MessageBoxButton.YesNoCancel, MessageBoxImage.Error);
{code:c#}

## How to customize it?

The main point of creating this WPF message box was to customize it, right? so I’d better show you how this is done.
To customize the WPFMessageBox we use the standard control templates way:

{code:xml}
<Style TargetType="msgbox:WPFMessageBoxControl">
    <Setter Property="Template">
        <Setter.Value>
            <ControlTemplate TargetType="{x:Type msgbox:WPFMessageBoxControl}">
                <!-- your new template here -->
            </ControlTemplate>
        </Setter.Value>
    </Setter>
</Style>
{code:xml}

## Can I see a real example of such customization?

Sure, following is the control template for the message box you see in the image on the Home screen. Note the binding you need to use to properly set the visibility of the buttons and the image.

{code:xml}
<Style TargetType="{x:Type msgbox:WPFMessageBoxControl}">
    <Setter Property="Template">
        <Setter.Value>
            <ControlTemplate TargetType="{x:Type msgbox:WPFMessageBoxControl}">
                <Grid Background="LightBlue" FlowDirection="{Binding ContentFlowDirection}">
                    <Grid.RowDefinitions>
                        <RowDefinition Height="55" />
                        <RowDefinition Height="2" />
                        <RowDefinition Height="*" />
                        <RowDefinition Height="40" />
                        <RowDefinition Height="55" />
                    </Grid.RowDefinitions>
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="60" />
                        <ColumnDefinition Width="*" />
                    </Grid.ColumnDefinitions>

                    <TextBlock Text="{Binding Message}" Grid.RowSpan="2" Grid.Column="0" Grid.ColumnSpan="2" TextWrapping="Wrap" TextAlignment="Left" HorizontalAlignment="{Binding ContentTextAlignment}" VerticalAlignment="Top" Margin="10 10 10 10" />

                    <Border Grid.Row="3" Grid.Column="0" Grid.ColumnSpan="2" Background="Yellow">
                        <StackPanel Orientation="Horizontal" VerticalAlignment="Center" HorizontalAlignment="Right" Margin="0 0 5 0" >
                            <Button Content="_Yes" Visibility="{Binding YesNoVisibility}" Command="{Binding YesCommand}" IsDefault="{Binding IsYesDefault}" Margin="5 5 5 5" Height="24" Width="80" />
                            <Button Content="_No" Visibility="{Binding YesNoVisibility}" Command="{Binding NoCommand}" IsDefault="{Binding IsNoDefault}" Margin="5 5 5 5" Height="24" Width="80" />
                            <Button Content="O_K" Visibility="{Binding OkVisibility}" Command="{Binding OkCommand}" IsDefault="{Binding IsOkDefault}" Margin="5 5 5 5" Height="24" Width="80" />
                            <Button Content="_Cancel" Visibility="{Binding CancelVisibility}" Command="{Binding CancelCommand}" IsDefault="{Binding IsCancelDefault}" Margin="5 5 5 5" Height="24" Width="80" />
                        </StackPanel>
                    </Border>
                            
                    <StackPanel Grid.Row="4" Grid.Column="0" Grid.ColumnSpan="2" Orientation="Horizontal">
                        <Image Source="{Binding MessageImageSource}" HorizontalAlignment="Left" VerticalAlignment="Center" Height="32" Width="32" Margin="10 0 0 0" />
                        <Image Source="{Binding MessageImageSource}" HorizontalAlignment="Left" VerticalAlignment="Center" Height="32" Width="32" Margin="10 0 0 0" />
                        <Image Source="{Binding MessageImageSource}" HorizontalAlignment="Left" VerticalAlignment="Center" Height="32" Width="32" Margin="10 0 0 0" />
                        <Image Source="{Binding MessageImageSource}" HorizontalAlignment="Left" VerticalAlignment="Center" Height="32" Width="32" Margin="10 0 0 0" />
                        <Image Source="{Binding MessageImageSource}" HorizontalAlignment="Left" VerticalAlignment="Center" Height="32" Width="32" Margin="10 0 0 0" />
                        <Image Source="{Binding MessageImageSource}" HorizontalAlignment="Left" VerticalAlignment="Center" Height="32" Width="32" Margin="10 0 0 0" />
                    </StackPanel>
                </Grid>

            </ControlTemplate>
        </Setter.Value>
    </Setter>
</Style>
{code:xml}